<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Panishment extends Model
{
    protected $table = 'panishments';
}
