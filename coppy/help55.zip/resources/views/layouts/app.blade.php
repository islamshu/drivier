<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>{{ Config('app.name')}}</title>
</head>
<body>
	<div style="margin: 50px auto;text-align:center;">
		<img alt="logo" width="200"  src="{{ asset('public/wtc_logo_gray.png')}}" class="theme-logo img-fluid">
		<h3>Soon ..</h3>
	</div>
</body>
</html>